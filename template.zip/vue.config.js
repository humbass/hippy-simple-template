module.exports = { 
  runtimeCompiler: true, 
}
